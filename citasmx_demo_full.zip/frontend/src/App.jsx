import React, { useState, useEffect } from 'react';

const ACCESS_KEY_ENV = import.meta.env.VITE_ACCESS_CODE || '';

function AccessGate({onPassed}) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  function submit(e){
    e.preventDefault();
    const allowed = ACCESS_KEY_ENV || window.localStorage.getItem('demo_access_code');
    if(!allowed){
      // If no env set, accept any code but store it (local dev)
      window.localStorage.setItem('demo_access_code', code);
      onPassed(code);
      return;
    }
    if(code === allowed){
      window.localStorage.setItem('demo_access_code', code);
      onPassed(code);
    } else {
      setError('Clave incorrecta');
    }
  }
  return (<div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}} >
    <div style={{width:360}}>
      <div className="card">
        <h3>Acceso privado — CitasMX Demo</h3>
        <p>Introduce la clave que te daré para entrar al demo privado.</p>
        <form onSubmit={submit}>
          <input className="input" placeholder="Clave de acceso" value={code} onChange={e=>setCode(e.target.value)} />
          <div style={{height:8}}/>
          <button className="button" type="submit">Entrar</button>
        </form>
        {error && <div style={{color:'crimson',marginTop:8}}>{error}</div>}
        <div style={{fontSize:12,marginTop:8,color:'#555'}}>Si no se ha configurado clave en el servidor, cualquier código funcionará en local.</div>
      </div>
    </div>
  </div>);
}

function mockProfiles(){
  return [
    {id:1,name:'María',age:27,city:'CDMX',bio:'Amo la cocina y el café.',img:'https://source.unsplash.com/collection/888146/400x300?sig=1',interests:['Café','Viajes']},
    {id:2,name:'Carlos',age:30,city:'Guadalajara',bio:'Guitarrista y fan del fútbol.',img:'https://source.unsplash.com/collection/888146/400x300?sig=2',interests:['Música','Deporte']},
    {id:3,name:'Sofía',age:24,city:'Monterrey',bio:'Diseñadora y amante de perros.',img:'https://source.unsplash.com/collection/888146/400x300?sig=3',interests:['Arte','Perros']}
  ];
}

export default function App(){
  const [passed, setPassed] = useState(!!window.localStorage.getItem('demo_access_code'));
  const [profiles, setProfiles] = useState(mockProfiles());
  const [likes, setLikes] = useState({});
  useEffect(()=> {
    const s = window.localStorage.getItem('demo_likes');
    if(s) setLikes(JSON.parse(s));
  },[]);
  useEffect(()=> {
    window.localStorage.setItem('demo_likes', JSON.stringify(likes));
  },[likes]);
  if(!passed) return <AccessGate onPassed={()=>setPassed(true)} />;

  return (<div>
    <header className="header">
      <div style={{fontWeight:700,color:'#e11d48'}}>❤️ CitasMX Demo (Privado)</div>
      <div>
        <button className="button" onClick={()=>{window.localStorage.clear(); window.location.reload();}}>Cerrar sesión (demo)</button>
      </div>
    </header>
    <div className="container">
      <div className="card">
        <h2>Personas cerca de ti</h2>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginTop:12}}>
          {profiles.map(p=>(
            <div key={p.id} className="card">
              <img src={p.img} alt={p.name} style={{width:'100%',height:160,objectFit:'cover',borderRadius:6}}/>
              <h3>{p.name}, <span style={{fontSize:13,color:'#666'}}>{p.age}</span></h3>
              <div style={{fontSize:13,color:'#666'}}>{p.city}</div>
              <p style={{marginTop:8}}>{p.bio}</p>
              <div style={{display:'flex',gap:8,marginTop:8}}>
                <button className="button" onClick={()=> setLikes(l=>({...l,[p.id]:!l[p.id]}))}>{likes[p.id] ? 'Te gusta' : 'Me gusta'}</button>
                <button className="button" onClick={()=> alert('Simulación de chat (demo)')}>Mensaje</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <h3>Configuración demo</h3>
        <p>Para probar funciones avanzadas (matching, moderación, backend) sigue el README en el ZIP que te doy.</p>
      </div>
    </div>
  </div>);
}
