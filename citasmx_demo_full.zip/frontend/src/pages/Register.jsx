import React, {useState} from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';

export default function Register({onRegister}) {
  const [email,setEmail]=useState('');
  const [pass,setPass]=useState('');
  const [name,setName]=useState('');
  const [error,setError]=useState('');
  async function submit(e){
    e.preventDefault();
    try{
      await createUserWithEmailAndPassword(auth, email, pass);
      onRegister && onRegister();
    }catch(err){
      setError(err.message || 'Error al registrar');
    }
  }
  return (<div style={{maxWidth:420,margin:'20px auto'}} className="card">
    <h3>Crear cuenta</h3>
    <form onSubmit={submit}>
      <input className="input" placeholder="Nombre" value={name} onChange={e=>setName(e.target.value)} />
      <div style={{height:8}} />
      <input className="input" placeholder="Correo" value={email} onChange={e=>setEmail(e.target.value)} />
      <div style={{height:8}} />
      <input className="input" placeholder="Contraseña" type="password" value={pass} onChange={e=>setPass(e.target.value)} />
      <div style={{height:8}} />
      <button className="button" type="submit">Crear cuenta</button>
    </form>
    {error && <div style={{color:'crimson',marginTop:8}}>{error}</div>}
  </div>);
}
