CitasMX Demo - Private deployment guide
======================================

This ZIP contains a minimal demo-ready project with frontend (React + Vite), backend (Express + SQLite),
and a tiny Expo mobile placeholder.

IMPORTANT: I cannot deploy to Vercel/Railway from here. This package is ready for you to deploy.
Follow the steps below to have a private demo (access protected with ACCESS_CODE).

1) Unzip & install
------------------
# Frontend
cd frontend
npm install
# Backend
cd ../backend
npm install

2) Configure environment
------------------------
Copy .env.example to .env in both frontend and backend and set values.
- Backend:
  ACCESS_CODE=Amor1234   # set your private demo code
  DATABASE_FILE=./data/db.sqlite
- Frontend:
  VITE_ACCESS_CODE=Amor1234
  VITE_BACKEND_URL=http://localhost:4000

3) Run locally (private demo)
-----------------------------
Start backend:
  cd backend
  node src/index.js

Start frontend (in another terminal):
  cd frontend
  npm run dev

Open the frontend URL (Vite will show it, typically http://localhost:5173).
You will be asked for the access code. Use the ACCESS_CODE value you set (e.g. Amor1234).

4) Deploying to the web (Vercel for frontend, Railway/Render for backend)
------------------------------------------------------------------------
- Frontend (Vercel):
  1. Create a Vercel account.
  2. Import the frontend folder as a new project.
  3. In Project Settings > Environment Variables, add:
     - VITE_ACCESS_CODE=Amor1234
     - VITE_BACKEND_URL=https://your-backend-url.example
  4. Deploy. The site will be protected by the access gate.

- Backend (Railway or Render):
  1. Create a service and deploy the backend folder.
  2. Set environment variables in the hosting UI:
     - ACCESS_CODE=Amor1234
     - DATABASE_FILE=./data/db.sqlite
  3. Start the service and copy the public URL to VITE_BACKEND_URL in Vercel.

5) How access protection works
------------------------------
- Backend checks the header 'x-access-code' or query param 'access_code' for the demo secret.
- Frontend Access Gate stores the key in localStorage after entry and will include it when calling APIs.
- On deployment, make sure to set the same ACCESS_CODE value in both frontend and backend environment variables.

6) Next steps & improvements
----------------------------
If you want I can:
- Provide curl commands to populate demo users.
- Add Firebase Auth integration (requires Firebase keys).
- Add Hugging Face moderation integration (requires HF API key).
- Add CI/CD instructions and GitHub Actions workflow.

Enjoy testing the private demo locally or on your hosting. ❤️



------------------------------------------------------------
ADDITIONAL IMPLEMENTATIONS ADDED
------------------------------------------------------------

1) Demo credentials & seed script
- backend/src/scripts/seed.js creates a JSON with demo credentials:
  - demo1@example.com / DemoPass123
  - demo2@example.com / DemoPass123
- Run it (from repo root): `node backend/src/scripts/seed.js`
- The frontend demo accepts any access key that matches ACCESS_CODE set in the env.

2) Firebase Auth integration (frontend)
- Files added:
  - frontend/src/firebase.js
  - frontend/src/pages/Login.jsx
  - frontend/src/pages/Register.jsx
- To enable: create a Firebase project, enable Email/Password auth, paste keys into frontend/.env

3) Hugging Face moderation (backend)
- Files added:
  - backend/src/moderation.js
  - backend/src/routes/moderation_integration.js
- To enable: set HF_API_KEY in backend/.env with your Hugging Face inference token.

4) How moderation is used
- The moderation route checks text with HF. If flagged, it returns 403 and a details object.
- In production, connect moderation checks to profile creation and messaging:
  - Call /api/moderation/check-text before saving bios or messages.
  - If flagged, store a report and optionally queue for human review.

5) Deployment notes (Vercel + Railway)
- Frontend (Vercel):
  - Import frontend directory as a Vercel project.
  - Set the environment variables (VITE_ACCESS_CODE, VITE_BACKEND_URL, VITE_FIREBASE_*).
  - Deploy; Vercel will build using `npm run build`.

- Backend (Railway / Render):
  - Create a new Node service, connect to your Git repo or upload files.
  - Set environment variables: ACCESS_CODE, HF_API_KEY (optional), DATABASE_FILE.
  - For persistent DB use Postgres; adapt `backend/src/services/db.js` to use Postgres / Prisma.

6) Quick Branding Guide (change name/logo/colors)
- Frontend:
  - Edit `frontend/index.html` title and `frontend/src/styles.css` colors.
  - Replace the header text in `frontend/src/App.jsx` or main component.
  - Replace any logo images located in `frontend/public` (create the folder and add files).
- To change primary color: update `.button` background in `frontend/src/styles.css` or integrate Tailwind and change theme colors.
- To change site name: update `<title>` and the header text.

If you want, I can now:
A) Produce a new ZIP with all these changes (including the seed and moderation files) -- I'll create `/mnt/data/citasmx_demo_full.zip`.
B) Provide step-by-step commands to deploy to Vercel + Railway and show screenshots (textual) to guide you.
C) Integrate Firebase Auth into the demo flow so users can register/login and the frontend shows authenticated state (I will add ProtectedRoute and small adjustments).

Tell me which of A/B/C (or multiple) you want next; I've already prepared the updated bundle and will zip it now.
