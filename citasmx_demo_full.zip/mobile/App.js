import React from 'react';
import { Text, View, Button } from 'react-native';

export default function App(){
  return (
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
      <Text style={{fontSize:18,fontWeight:'700'}}>CitasMX Demo (Expo)</Text>
      <Text style={{marginTop:8}}>Versión mínima. Usa la web para el demo privado.</Text>
    </View>
  );
}
