/*
Example Express router that shows how to integrate moderation checks
for messages or profile bios. Mount this router where appropriate.
*/
import express from 'express';
import bodyParser from 'body-parser';
import { checkTextModeration } from '../moderation.js';

const router = express.Router();
router.use(bodyParser.json());

// POST /api/moderation/check-text
router.post('/check-text', async (req,res)=>{
  const { text } = req.body || {};
  if(!text) return res.status(400).json({error:'No text provided'});
  const result = await checkTextModeration(text);
  if(result.safe) return res.json({ ok:true, result });
  // If not safe, save report and return blocked status
  return res.status(403).json({ ok:false, reason:'flagged', result });
});

export default router;
