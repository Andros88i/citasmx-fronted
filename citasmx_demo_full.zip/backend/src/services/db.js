import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const DB_FILE = process.env.DATABASE_FILE || path.resolve('data','db.sqlite');
export function initDb(){
  const dir = path.dirname(DB_FILE);
  if(!fs.existsSync(dir)) fs.mkdirSync(dir, {recursive:true});
  const db = new Database(DB_FILE);
  // create tables if not exist
  db.exec(`CREATE TABLE IF NOT EXISTS likes (id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER, at TEXT);`);
  // seed profiles table conceptually (we'll return static objects for demo)
  db.close();
}

// Return demo profiles
export function getProfiles(){
  return [
    {id:1,name:'María',age:27,city:'CDMX',bio:'Amo la cocina y el café.',img:'https://source.unsplash.com/collection/888146/400x300?sig=1',interests:['Café','Viajes']},
    {id:2,name:'Carlos',age:30,city:'Guadalajara',bio:'Guitarrista y fan del fútbol.',img:'https://source.unsplash.com/collection/888146/400x300?sig=2',interests:['Música','Deporte']},
    {id:3,name:'Sofía',age:24,city:'Monterrey',bio:'Diseñadora y amante de perros.',img:'https://source.unsplash.com/collection/888146/400x300?sig=3',interests:['Arte','Perros']}
  ];
}

export function addLike(profileId){
  const db = new Database(DB_FILE);
  const stmt = db.prepare('INSERT INTO likes (profile_id, at) VALUES (?,?)');
  stmt.run(profileId, new Date().toISOString());
  db.close();
}

export function getMatches(userId){
  // Simple score-based ranking for demo (returns same profiles)
  const profiles = getProfiles().filter(p=>p.id!==userId);
  return profiles.map(p=>({profile:p,score:Math.floor(Math.random()*100)})).sort((a,b)=>b.score-a.score);
}
