/*
Seed script for demo data.
This creates a simple JSON file with demo credentials and optional profiles.
Run: node src/scripts/seed.js
*/
import fs from 'fs';
import path from 'path';
const out = path.resolve('data','demo_users.json');
const demo = {
  credentials:[
    {email:'demo1@example.com', password:'DemoPass123', name:'Demo User 1'},
    {email:'demo2@example.com', password:'DemoPass123', name:'Demo User 2'}
  ],
  profiles:[
    {id:1,name:'María',age:27,city:'CDMX',bio:'Amo la cocina y el café.',img:'https://source.unsplash.com/collection/888146/400x300?sig=11',interests:['Café','Viajes']},
    {id:2,name:'Carlos',age:30,city:'Guadalajara',bio:'Guitarrista y fan del fútbol.',img:'https://source.unsplash.com/collection/888146/400x300?sig=12',interests:['Música','Deporte']},
    {id:3,name:'Sofía',age:24,city:'Monterrey',bio:'Diseñadora y amante de perros.',img:'https://source.unsplash.com/collection/888146/400x300?sig=13',interests:['Arte','Perros']}
  ]
};
fs.mkdirSync(path.dirname(out), {recursive:true});
fs.writeFileSync(out, JSON.stringify(demo,null,2), 'utf-8');
console.log('Wrote demo users to', out);
