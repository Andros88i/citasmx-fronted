/*
Hugging Face moderation helper (server-side)
- Requires HF_API_KEY in backend env
- Exports checkTextModeration(text) that returns { safe: boolean, details: object }
*/
import fetch from 'node-fetch';

const HF_API = 'https://api-inference.huggingface.co/models/moderation';
const HF_KEY = process.env.HF_API_KEY || '';

export async function checkTextModeration(text){
  if(!HF_KEY) {
    // If no key, treat as safe for demo but return note
    return { safe:true, note:'No HF key configured (demo mode)' };
  }
  try{
    const res = await fetch(HF_API, {
      method:'POST',
      headers:{
        'Authorization': `Bearer ${HF_KEY}`,
        'Content-Type':'application/json'
      },
      body: JSON.stringify({ inputs: text })
    });
    const data = await res.json();
    // The structure depends on the model; here we'll treat presence of "flagged" fields
    // HF moderation models often return {id, model, flagged: bool, categories: {...}}
    // We'll attempt to detect common patterns:
    const flagged = (data && (data.flagged || data[0]?.flagged || false));
    return { safe: !flagged, details: data };
  }catch(err){
    return { safe:true, note:'HF request failed: '+String(err) };
  }
}
