import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import bodyParser from 'body-parser';
import { initDb, getProfiles, addLike, getMatches } from './services/db.js';

dotenv.config();
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Simple access code middleware for private demo
const ACCESS_CODE = process.env.ACCESS_CODE || '';
function accessGate(req,res,next){
  if(!ACCESS_CODE) return next(); // no gate set
  const code = req.headers['x-access-code'] || req.query.access_code;
  if(code === ACCESS_CODE) return next();
  return res.status(401).json({error:'Access code required'});
}

initDb();

// Public health
app.get('/api/health',(req,res)=>res.json({ok:true,now:new Date().toISOString()}));

// Profiles (demo returns static set)
app.get('/api/profiles', accessGate, (req,res)=>{
  const profiles = getProfiles();
  res.json(profiles);
});

// Like endpoint (demo)
app.post('/api/profiles/:id/like', accessGate, (req,res)=>{
  const id = Number(req.params.id);
  addLike(id);
  res.json({ok:true});
});

// Match endpoint
app.get('/api/match', accessGate, (req,res)=>{
  const userId = Number(req.query.userId || 0);
  const matches = getMatches(userId);
  res.json(matches);
});

const PORT = process.env.PORT || 4000;

import moderationRouter from './routes/moderation_integration.js';
app.use('/api/moderation', moderationRouter);

app.listen(PORT, ()=> console.log('Backend listening on',PORT));
